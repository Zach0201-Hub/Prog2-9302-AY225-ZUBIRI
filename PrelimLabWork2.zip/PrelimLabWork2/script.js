// Hardcoded login credentials
const correctUsername = "Zach Aeon R. Zubiri";
const correctPassword = "sirvalpogi1234";

// Beep sound
const beepSound = new Audio("beep.mp3");

// Attendance records array
let attendanceRecords = [];

// Handle form submission
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const messageDiv = document.getElementById("message");
    const timestampDiv = document.getElementById("timestamp");

    if (username === correctUsername && password === correctPassword) {
        // Get current date and time
        const now = new Date();
        const timestamp = formatDate(now);

        messageDiv.style.color = "green";
        messageDiv.textContent = "Login successful! Welcome, " + username;
        timestampDiv.textContent = "Time In: " + timestamp;

        // Save attendance
        attendanceRecords.push({
            username: username,
            timeIn: timestamp
        });

        // Generate attendance file
        generateAttendanceFile();
    } else {
        messageDiv.style.color = "red";
        messageDiv.textContent = "Incorrect username or password!";
        timestampDiv.textContent = "";

        // Play beep sound
        beepSound.play();
    }
});

// Format date and time
function formatDate(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = date.getFullYear();

    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${month}/${day}/${year} ${hours}:${minutes}:${seconds}`;
}

// Generate attendance summary file
function generateAttendanceFile() {
    let content = "ATTENDANCE SUMMARY\n\n";

    attendanceRecords.forEach(record => {
        content += `Username: ${record.username}\n`;
        content += `Time In: ${record.timeIn}\n`;
        content += "----------------------\n";
    });

    const blob = new Blob([content], { type: "text/plain" });
    const link = document.createElement("a");

    link.href = URL.createObjectURL(blob);
    link.download = "attendance_summary.txt";
    link.click();
}
